JLotoPrint
==========

A print/PDF tool for lottery tickets generation.

<h2>Features:</h2>
<p>
  <ul>
    <li>Generate a template for the ticket model</li>
    <li>Import game numbers and generate the printable tickets</li>
  </ul>
</p>
<h2>Requirements:</h2>
<p>
  <ul>
    <li>Java Runtime Environment (JRE) 8 or above</li>
  <ul>
</p>
